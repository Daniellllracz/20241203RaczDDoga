﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _20241203DolgozatRaczD;

public class Program
{
    private static readonly Random RandomGenerator = new();

    public static void Main()
    {
        List<Book> books = GenerateRandomBooks(15);
        double totalRevenue = 0;
        int initialStock = books.Sum(b => b.Stock); 
        int outOfStockCount = 0; 

        for (int i = 0; i < 100; i++)
        {
            Book bookToBuy = books[RandomGenerator.Next(books.Count)];

            if (bookToBuy.Stock > 0)
            {

                bookToBuy.Stock--;  
                totalRevenue += bookToBuy.Price;
                Console.WriteLine($"Vásárlás sikeres: {bookToBuy.Title} - Bevétel: {bookToBuy.Price} Ft");
            }
            else
            {

                bool restocked = RandomGenerator.NextDouble() < 0.5;

                if (restocked)
                {

                    int restockAmount = RandomGenerator.Next(1, 11);
                    bookToBuy.Stock += restockAmount;  
                    Console.WriteLine($"A könyv újra raktáron van: {bookToBuy.Title} +{restockAmount} darab.");
                }
                else
                {

                    books.Remove(bookToBuy);
                    outOfStockCount++; 
                    Console.WriteLine($"A könyv elfogyott a nagykerben: {bookToBuy.Title}. Eltávolítva a listáról.");
                }
            }
        }

        int finalStock = books.Sum(b => b.Stock); 
        int stockDifference = initialStock - finalStock; 

        Console.WriteLine($"\nÖsszes bevétel: {totalRevenue} Ft");
        Console.WriteLine($"A nagykerből {outOfStockCount} könyv fogyott ki.");
        Console.WriteLine($"A raktárkészlet változása: {stockDifference} darab");
        Console.WriteLine($"Kezdeti készlet: {initialStock}, Végső készlet: {finalStock}");
    }

    public static List<Book> GenerateRandomBooks(int count)
    {
        List<Book> books = new();
        HashSet<string> usedIsbn = new();

        for (int i = 0; i < count; i++)
        {
            string isbn;
            do
            {
                isbn = GenerateRandomISBN();
            } while (usedIsbn.Contains(isbn));

            usedIsbn.Add(isbn);

            string language = RandomGenerator.NextDouble() < 0.8 ? "Magyar" : "Angol";
            string title = language == "Magyar" ? GenerateRandomHungarianTitle() : GenerateRandomEnglishTitle();
            int stock = RandomGenerator.NextDouble() < 0.3 ? 0 : RandomGenerator.Next(5, 11);
            int authorCount = RandomGenerator.NextDouble() < 0.7 ? 1 : RandomGenerator.Next(2, 4);

            List<Author> authors = new();
            for (int j = 0; j < authorCount; j++)
            {
                authors.Add(new Author(GenerateRandomAuthorName()));
            }

            int publicationYear = RandomGenerator.Next(2007, DateTime.Now.Year + 1);
            int price = RandomGenerator.Next(10, 101) * 100;

            books.Add(new Book(isbn, authors, title, publicationYear, language, stock, price));
        }

        return books;
    }

    private static string GenerateRandomISBN()
    {
        return new string(Enumerable.Range(0, 10).Select(_ => RandomGenerator.Next(0, 10).ToString()[0]).ToArray());
    }

    private static string GenerateRandomHungarianTitle()
    {
        string[] titles = { "A Végtelen Kaland", "Magyar Mítoszok", "Történetek az Alföldről", "A Dunánál", "Tavaszi Szél" };
        return titles[RandomGenerator.Next(titles.Length)];
    }

    private static string GenerateRandomEnglishTitle()
    {
        string[] titles = { "Infinite Adventure", "Legends of the North", "Tales from the Wild", "Riverfront Stories", "Spring Breeze" };
        return titles[RandomGenerator.Next(titles.Length)];
    }

    private static string GenerateRandomAuthorName()
    {
        string[] firstNames = { "John", "Jane", "Peter", "Anna", "Paul", "Krisztina", "Gábor", "Béla" };
        string[] lastNames = { "Smith", "Doe", "Kovács", "Nagy", "Tóth", "Hoffman", "Taylor", "Brown" };

        return $"{firstNames[RandomGenerator.Next(firstNames.Length)]} {lastNames[RandomGenerator.Next(lastNames.Length)]}";
    }
}