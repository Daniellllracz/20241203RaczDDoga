﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _20241203DolgozatRaczD
{
    public class Book
    {
        public string ISBN { get; private set; }
        public List<Author> Authors { get; private set; }
        public string Title { get; private set; }
        public int PublicationYear { get; private set; }
        public string Language { get; private set; }
        public int Stock { get; set;}
        public int Price { get; private set; }

        private static readonly HashSet<string> ValidLanguages = new() { "Angol", "Német", "Magyar" };
        private static readonly Random RandomGenerator = new();

        public Book(string isbn, List<Author> authors, string title, int publicationYear, string language, int stock, int price)
        {
            if (string.IsNullOrWhiteSpace(isbn) || isbn.Length != 10 || !isbn.All(char.IsDigit))
                throw new ArgumentException("ISBN egy 10 számjegyű azonosítónak kell lennie");

            if (authors == null || authors.Count < 1 || authors.Count > 3)
                throw new ArgumentException("A szerző 1-3 példányt tartalmazhat");

            if (string.IsNullOrWhiteSpace(title) || title.Length < 3 || title.Length > 64)
                throw new ArgumentException("A szöveg minimum 3 és maximum 64 karaktert tartalmazhat");

            if (publicationYear < 2007 || publicationYear > DateTime.Now.Year)
                throw new ArgumentException("Kiadási évnek 2007 és a jelenlegi év között kell lennie");

            if (!ValidLanguages.Contains(language))
                throw new ArgumentException("Az elfogadott nyelvek csak az Angol, Német, Magyar");

            if (stock < 0)
                throw new ArgumentException("A készleten lévő mennyiség nem lehet negatív, szóval minimum 0");

            if (price < 1000 || price > 10000 || price % 100 != 0)
                throw new ArgumentException("Az árnak 1000 és 10000 között kell lennie, és oszthatónak kell lennie 100-al");

            ISBN = isbn;
            Authors = authors;
            Title = title;
            PublicationYear = publicationYear;
            Language = language;
            Stock = stock;
            Price = price;
        }

        public Book(string title, string authorName)
            : this(GenerateRandomISBN(), new List<Author> { new Author(authorName) }, title, 2024, "Magyar", 0, 4500)
        {
        }

        private static string GenerateRandomISBN()
        {
            return new string(Enumerable.Range(0, 10).Select(_ => RandomGenerator.Next(0, 10).ToString()[0]).ToArray());
        }

        public override string ToString()
        {
            string authorLabel = Authors.Count == 1 ? "Szerző" : "Szerzők";
            string stockStatus = Stock == 0 ? "Beszerzés alatt" : $"{Stock} db";

            return $"Cím: {Title}, {authorLabel}: {string.Join(", ", Authors)}, " +
                   $"Év: {PublicationYear}, Nyelv: {Language}, " +
                   $"Készlet: {stockStatus}, Ár: {Price} HUF, ISBN: {ISBN}";
        }
    }
}
    