﻿using System;

public class Author
{
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public Guid AuthorId { get; private set; }

    public Author(string fullName)
    {
        if (string.IsNullOrWhiteSpace(fullName))
            throw new ArgumentException("A teljes név nem lehet üres vagy csak szóköz.");

        var nameParts = fullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        if (nameParts.Length != 2)
            throw new ArgumentException("A névnek pontosan két részből kell állnia (keresztnév és vezetéknév).");

        FirstName = ValidateNamePart(nameParts[0], "Keresztnév");
        LastName = ValidateNamePart(nameParts[1], "Vezetéknév");

        AuthorId = Guid.NewGuid();
    }

    private string ValidateNamePart(string namePart, string fieldName)
    {
        if (namePart.Length < 3 || namePart.Length > 32)
            throw new ArgumentException($"{fieldName} hosszának 3 és 32 karakter között kell lennie.");

        return namePart;
    }

    public override string ToString()
    {
        return $"{FirstName} {LastName} (ID: {AuthorId})";
    }
}
